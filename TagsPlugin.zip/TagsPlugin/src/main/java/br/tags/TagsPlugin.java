package br.tags;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class TagsPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("tag").setExecutor(this);
        getCommand("tag").setTabCompleter(this);
        Bukkit.getOnlinePlayers().forEach(this::applyTag);
    }

    @Override
    public void onDisable() {
        Bukkit.getOnlinePlayers().forEach(this::clearTeam);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String msg(String key) {
        return color(getConfig().getString("messages." + key, key));
    }

    // ---------- Resource pack ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        applyTag(p);

        if (!getConfig().getBoolean("resource-pack.enabled", true)) return;
        String url = getConfig().getString("resource-pack.url", "");
        if (url == null || url.isBlank()) return;

        long delay = getConfig().getLong("resource-pack.delay-ticks", 20);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            byte[] hash = hexToBytes(getConfig().getString("resource-pack.sha1", ""));
            String prompt = color(getConfig().getString("resource-pack.prompt", ""));
            boolean force = getConfig().getBoolean("resource-pack.force", false);
            p.setResourcePack(url, hash, prompt, force);
        }, delay);
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent e) {
        if (e.getStatus() == PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD) {
            e.getPlayer().sendMessage(msg("pack-failed"));
        }
    }

    private byte[] hexToBytes(String hex) {
        if (hex == null || hex.length() != 40) return null;
        byte[] out = new byte[20];
        try {
            for (int i = 0; i < 20; i++) {
                out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
            }
        } catch (NumberFormatException ex) {
            getLogger().warning("sha1 inválido no config.yml, enviando sem hash.");
            return null;
        }
        return out;
    }

    // ---------- Tags ----------

    private String tagDisplay(String id) {
        if (id == null) return "";
        return color(getConfig().getString("tags." + id + ".display", ""));
    }

    private boolean canUse(Player p, String id) {
        ConfigurationSection t = getConfig().getConfigurationSection("tags." + id);
        if (t == null) return false;
        if (!t.getBoolean("permission", true)) return true;
        return p.hasPermission("tags.admin") || p.hasPermission("tags.use." + id);
    }

    private String selected(Player p) {
        String id = data.getString(p.getUniqueId().toString());
        // se a tag foi apagada do config ou o jogador perdeu a permissão, ignora
        if (id == null || !getConfig().isConfigurationSection("tags." + id) || !canUse(p, id)) return null;
        return id;
    }

    private void applyTag(Player p) {
        String prefix = tagDisplay(selected(p));

        if (getConfig().getBoolean("display.tablist", true)) {
            p.setPlayerListName(prefix.isEmpty() ? null : prefix + " " + p.getName());
        }

        if (getConfig().getBoolean("display.nametag", true)) {
            if (prefix.isEmpty()) {
                clearTeam(p);
            } else {
                Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
                String name = teamName(p);
                Team team = sb.getTeam(name);
                if (team == null) team = sb.registerNewTeam(name);
                String full = prefix + " ";
                team.setPrefix(full.length() > 64 ? full.substring(0, 64) : full);
                if (!team.hasEntry(p.getName())) team.addEntry(p.getName());
            }
        }
    }

    private String teamName(Player p) {
        return "tg_" + p.getUniqueId().toString().replace("-", "").substring(0, 12);
    }

    private void clearTeam(Player p) {
        Team team = Bukkit.getScoreboardManager().getMainScoreboard().getTeam(teamName(p));
        if (team != null) team.unregister();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncPlayerChatEvent e) {
        if (!getConfig().getBoolean("display.chat", true)) return;
        String prefix = tagDisplay(selected(e.getPlayer()));
        if (prefix.isEmpty()) return;
        e.setFormat(prefix.replace("%", "%%") + " " + e.getFormat());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        clearTeam(e.getPlayer());
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Não consegui salvar data.yml: " + ex.getMessage());
        }
    }

    // ---------- Comando ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("tags.admin")) {
                sender.sendMessage(msg("no-permission"));
                return true;
            }
            reloadConfig();
            Bukkit.getOnlinePlayers().forEach(this::applyTag);
            sender.sendMessage(msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage("Só jogadores podem usar /tag.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            ConfigurationSection tags = getConfig().getConfigurationSection("tags");
            p.sendMessage(ChatColor.YELLOW + "Suas tags:");
            if (tags != null) {
                for (String id : tags.getKeys(false)) {
                    if (canUse(p, id)) {
                        p.sendMessage(ChatColor.GRAY + " - " + ChatColor.WHITE + id + ChatColor.GRAY + "  " + tagDisplay(id));
                    }
                }
            }
            p.sendMessage(ChatColor.GRAY + "Use /tag <nome> ou /tag off");
            return true;
        }

        if (args[0].equalsIgnoreCase("off")) {
            data.set(p.getUniqueId().toString(), null);
            save();
            applyTag(p);
            p.sendMessage(msg("removed"));
            return true;
        }

        String id = args[0].toLowerCase();
        if (!getConfig().isConfigurationSection("tags." + id)) {
            p.sendMessage(msg("not-found"));
            return true;
        }
        if (!canUse(p, id)) {
            p.sendMessage(msg("no-permission"));
            return true;
        }

        data.set(p.getUniqueId().toString(), id);
        save();
        applyTag(p);
        p.sendMessage(msg("equipped").replace("%tag%", tagDisplay(id)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length != 1) return Collections.emptyList();
        List<String> opts = new ArrayList<>(List.of("list", "off"));
        if (sender.hasPermission("tags.admin")) opts.add("reload");
        ConfigurationSection tags = getConfig().getConfigurationSection("tags");
        if (tags != null && sender instanceof Player p) {
            for (String id : tags.getKeys(false)) if (canUse(p, id)) opts.add(id);
        }
        return opts.stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
    }
}
